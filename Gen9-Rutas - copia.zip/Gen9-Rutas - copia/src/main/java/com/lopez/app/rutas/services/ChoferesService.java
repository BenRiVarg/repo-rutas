package com.lopez.app.rutas.services;

import com.lopez.app.rutas.models.Chofer;
import com.lopez.app.rutas.repositories.ChoferesRepository;
import com.lopez.app.rutas.repositories.IRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ChoferesService implements IService <Chofer>{




    private IRepository<Chofer> ChoferesRespo;

    public ChoferesService(Connection conn){
        ChoferesRespo = new ChoferesRepository(conn);
    }

    @Override
    public Optional<Chofer> getById(Long id) {
        try {
            return Optional.ofNullable(ChoferesRespo.getById(id));

        }
        catch (SQLException e){
            throw  new RuntimeException(e.getMessage(),e.getCause());
        }
    }

    public List<Chofer> listar() {
       try {
           return ChoferesRespo.listar();

       }
       catch (SQLException e){
           throw  new RuntimeException(e.getMessage(),e.getCause());
       }
    }

    @Override
    public void guardar(Chofer chofer) {
        try {
             ChoferesRespo.guardar(chofer);

        }
        catch (SQLException e){
            throw  new RuntimeException(e.getMessage(),e.getCause());
        }
    }

    @Override
    public void eliminar(Long id) {
        try {
             ChoferesRespo.eliminar(id);

        }
        catch (SQLException e){
            throw  new RuntimeException(e.getMessage(),e.getCause());
        }
    }
}
