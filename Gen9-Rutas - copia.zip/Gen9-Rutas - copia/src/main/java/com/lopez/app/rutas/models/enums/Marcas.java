package com.lopez.app.rutas.models.enums;

public enum Marcas {
    VOLVO,
    ALLIANCE,
    FORD,
    DINA,
    MERCEDEZ_BENZ

}
